package main;

import vista.Comienzo;

public class App {
    public static void main(String[] args) throws Exception {
        Comienzo frame = new Comienzo();
        frame.setVisible(true);
    }


   




}
