package modelo;

public class Propuesta {
	
	private Usuario quien;
	private Pelicula que;
	
	
	
	
	
	public Propuesta(Usuario quienLaPropone,Pelicula quePropone) {

		this.quien=quienLaPropone;
		this.que=quePropone;
		
	}
	
	
	
	
	
}